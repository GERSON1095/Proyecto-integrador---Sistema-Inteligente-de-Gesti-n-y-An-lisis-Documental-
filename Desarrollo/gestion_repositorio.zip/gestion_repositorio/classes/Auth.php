<?php
session_start();

class Auth {
    public static function login($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role'];
    }

    public static function logout() {
        session_destroy();
    }

    public static function check() {
        return isset($_SESSION['user_id']);
    }

    public static function userId() {
        return $_SESSION['user_id'] ?? null;
    }

    public static function userName() {
        return $_SESSION['user_name'] ?? null;
    }

    public static function requireLogin() {
        if (!self::check()) {
            header('Location: login.php');
            exit;
        }
    }
}