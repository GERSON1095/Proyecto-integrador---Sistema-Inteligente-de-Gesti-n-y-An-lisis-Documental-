<?php
require_once __DIR__ . '/../../classes/Auth.php';
Auth::requireLogin();
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">
            <i class="bi bi-folder2-open"></i> Gestión Repositorio
        </a>
        <div class="d-flex align-items-center text-white">
            <span class="me-3">Hola, <?= htmlspecialchars(Auth::userName()) ?></span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Salir</a>
        </div>
    </div>
</nav>