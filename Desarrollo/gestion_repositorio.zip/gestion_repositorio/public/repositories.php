<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Repository.php';

Auth::requireLogin();
$repoModel = new Repository();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
    $repoModel->create(Auth::userId(), $_POST['name'], $_POST['description'] ?? null);
    header('Location: repositories.php');
    exit;
}

if (isset($_GET['delete'])) {
    $repoModel->delete((int)$_GET['delete'], Auth::userId());
    header('Location: repositories.php');
    exit;
}

$repos = $repoModel->getByUser(Auth::userId());
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Repositorios</h2>
        <a href="dashboard.php" class="btn btn-secondary btn-sm">Volver</a>
    </div>

    <div class="card mb-4 shadow-sm">
        <div class="card-header">Crear nuevo repositorio</div>
        <div class="card-body">
            <form method="POST" class="row g-3">
                <div class="col-md-5">
                    <input type="text" name="name" class="form-control" placeholder="Nombre del repositorio" required>
                </div>
                <div class="col-md-5">
                    <input type="text" name="description" class="form-control" placeholder="Descripción (opcional)">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Crear</button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <?php if (empty($repos)): ?>
                <p class="text-muted">No hay repositorios creados.</p>
            <?php else: ?>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Creado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($repos as $repo): ?>
                            <tr>
                                <td><?= htmlspecialchars($repo['name']) ?></td>
                                <td><?= htmlspecialchars($repo['description'] ?? '-') ?></td>
                                <td><?= $repo['created_at'] ?></td>
                                <td>
                                    <a href="documents.php?repo=<?= $repo['id'] ?>" class="btn btn-sm btn-primary">Ver Dashboard</a>
                                    <a href="?delete=<?= $repo['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar repositorio?')">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 