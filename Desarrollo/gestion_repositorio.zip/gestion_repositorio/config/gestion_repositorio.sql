
CREATE DATABASE IF NOT EXISTS gestion_repositorio
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE gestion_repositorio;

-- Tabla: users
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla: repositories

CREATE TABLE repositories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabla: documents
CREATE TABLE documents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    repository_id INT NOT NULL,
    user_id INT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type ENUM('pdf', 'docx', 'txt') NOT NULL,
    file_size INT NULL,
    status ENUM('pending', 'processing', 'completed', 'error') DEFAULT 'pending',
    category VARCHAR(100) NULL,
    summary TEXT NULL,
    extracted_data JSON NULL,
    full_text LONGTEXT NULL,
    error_message TEXT NULL,
    processed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (repository_id) REFERENCES repositories(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabla: processing_logs
CREATE TABLE processing_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    document_id INT NULL,
    level ENUM('info', 'warning', 'error') DEFAULT 'info',
    message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Tabla: queries
CREATE TABLE queries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    question TEXT NULL,
    answer TEXT NULL,
    document_ids JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Índices adicionales para mejorar búsquedas

CREATE INDEX idx_documents_user ON documents(user_id);
CREATE INDEX idx_documents_repo ON documents(repository_id);
CREATE INDEX idx_documents_status ON documents(status);
CREATE INDEX idx_documents_category ON documents(category);