<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Document.php';
require_once __DIR__ . '/../classes/Database.php';

Auth::requireLogin();

$docModel = new Document();
$doc = $docModel->findById((int)($_GET['id'] ?? 0));

if (!$doc || $doc['user_id'] != Auth::userId()) {
    header('Location: dashboard.php');
    exit;
}


if (isset($_GET['delete']) && $_GET['delete'] == $doc['id']) {
    
    if (file_exists($doc['file_path'])) {
        unlink($doc['file_path']);
    }
    
    $pdo = Database::getInstance()->getConnection();
    $stmt = $pdo->prepare("DELETE FROM documents WHERE id = ? AND user_id = ?");
    $stmt->execute([$doc['id'], Auth::userId()]);

    header('Location: documents.php?repo=' . $doc['repository_id']);
    exit;
}

$extracted = json_decode($doc['extracted_data'] ?? '{}', true);
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><?= htmlspecialchars($doc['original_name']) ?></h2>
        <div>
            <a href="download.php?id=<?= $doc['id'] ?>" class="btn btn-success btn-sm">
                <i class="bi bi-download"></i> Descargar
            </a>
            <a href="?id=<?= $doc['id'] ?>&delete=<?= $doc['id'] ?>" 
               class="btn btn-danger btn-sm"
               onclick="return confirm('¿Estás seguro de eliminar este documento? Esta acción no se puede deshacer.')">
                <i class="bi bi-trash"></i> Eliminar
            </a>
            <a href="javascript:history.back()" class="btn btn-secondary btn-sm">Volver</a>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header">Información</div>
                <div class="card-body">
                    <p><strong>Estado:</strong> 
                        <span class="badge bg-<?= $doc['status'] === 'completed' ? 'success' : ($doc['status'] === 'error' ? 'danger' : 'secondary') ?>">
                            <?= $doc['status'] ?>
                        </span>
                    </p>
                    <p><strong>Categoría:</strong> <?= htmlspecialchars($doc['category'] ?? '-') ?></p>
                    <p><strong>Tipo:</strong> <?= strtoupper($doc['file_type']) ?></p>
                    <p><strong>Tamaño:</strong> <?= number_format($doc['file_size'] / 1024, 1) ?> KB</p>
                    <p><strong>Procesado:</strong> <?= $doc['processed_at'] ?? '-' ?></p>
                    <p><strong>Subido:</strong> <?= $doc['created_at'] ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm mb-3">
                <div class="card-header">Resumen generado por IA</div>
                <div class="card-body">
                    <?= nl2br(htmlspecialchars($doc['summary'] ?? 'Sin resumen')) ?>
                </div>
            </div>

            <div class="card shadow-sm">
                <div class="card-header">Información extraída</div>
                <div class="card-body">
                    <?php if ($extracted): ?>
                        <pre class="mb-0" style="white-space: pre-wrap;"><?= htmlspecialchars(json_encode($extracted, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre>
                    <?php else: ?>
                        <p class="text-muted">No se extrajo información estructurada.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>