<?php
return [
    'host'     => 'localhost',
    'dbname'   => 'gestion_repositorio',
    'username' => 'root',
    'password' => '',          
    'charset'  => 'utf8mb4'
];