<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Document.php';

Auth::requireLogin();

$docId = (int)($_GET['id'] ?? 0);
$docModel = new Document();
$doc = $docModel->findById($docId);

if (!$doc || $doc['user_id'] != Auth::userId()) {
    die('Documento no encontrado o no tienes permiso.');
}

$filePath = $doc['file_path'];
$originalName = $doc['original_name'];

if (!file_exists($filePath)) {
    die('El archivo físico no existe en el servidor.');
}


header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($originalName) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filePath));

readfile($filePath);
exit;