<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Document.php';
require_once __DIR__ . '/../classes/Repository.php';
require_once __DIR__ . '/../classes/Database.php';

Auth::requireLogin();

$repoId = (int)($_GET['repo'] ?? 0);
$repoModel = new Repository();
$repo = $repoModel->findById($repoId, Auth::userId());

if (!$repo) {
    header('Location: repositories.php');
    exit;
}

$docModel = new Document();


if (isset($_GET['delete'])) {
    $docId = (int)$_GET['delete'];
    $doc = $docModel->findById($docId);

    if ($doc && $doc['user_id'] == Auth::userId()) {
        if (file_exists($doc['file_path'])) {
            unlink($doc['file_path']);
        }
        $pdo = Database::getInstance()->getConnection();
        $stmt = $pdo->prepare("DELETE FROM documents WHERE id = ? AND user_id = ?");
        $stmt->execute([$docId, Auth::userId()]);
    }
    header("Location: documents.php?repo=" . $repoId);
    exit;
}

$documents = $docModel->getByRepository($repoId);
$stats = $docModel->getStatsByRepository($repoId);
$categoryStats = $docModel->getCategoryStatsByRepository($repoId);
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-0">Dashboard – <?= htmlspecialchars($repo['name']) ?></h2>
            <?php if (!empty($repo['description'])): ?>
                <small class="text-muted"><?= htmlspecialchars($repo['description']) ?></small>
            <?php endif; ?>
        </div>
        <div>
            <a href="upload.php" class="btn btn-primary btn-sm">
                <i class="bi bi-cloud-upload"></i> Subir nuevo
            </a>
            <a href="repositories.php" class="btn btn-secondary btn-sm">Volver</a>
        </div>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-primary border-4">
                <div class="card-body py-3">
                    <h6 class="text-muted mb-1">Total Documentos</h6>
                    <h3 class="mb-0"><?= $stats['total'] ?? 0 ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-success border-4">
                <div class="card-body py-3">
                    <h6 class="text-muted mb-1">Procesados</h6>
                    <h3 class="mb-0 text-success"><?= $stats['completed'] ?? 0 ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-warning border-4">
                <div class="card-body py-3">
                    <h6 class="text-muted mb-1">Pendientes</h6>
                    <h3 class="mb-0 text-warning"><?= $stats['pending'] ?? 0 ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm border-start border-danger border-4">
                <div class="card-body py-3">
                    <h6 class="text-muted mb-1">Errores</h6>
                    <h3 class="mb-0 text-danger"><?= $stats['errors'] ?? 0 ?></h3>
                </div>
            </div>
        </div>
    </div>

    
    <?php if (!empty($categoryStats)): ?>
    <div class="card shadow-sm mb-4">
        <div class="card-header">
            <i class="bi bi-tags"></i> Distribución por categoría (IA)
        </div>
        <div class="card-body">
            <div class="row g-2">
                <?php foreach ($categoryStats as $cat): ?>
                    <div class="col-auto">
                        <span class="badge bg-primary fs-6 px-3 py-2">
                            <?= htmlspecialchars($cat['category']) ?>: <?= $cat['total'] ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>Documentos del repositorio</span>
            <span class="badge bg-secondary"><?= count($documents) ?> archivo(s)</span>
        </div>
        <div class="card-body">
            <?php if (empty($documents)): ?>
                <p class="text-muted mb-0">No hay documentos en este repositorio. <a href="upload.php">Sube el primero</a>.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Categoría</th>
                                <th>Fecha</th>
                                <th style="width: 180px;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($documents as $doc): ?>
                                <tr>
                                    <td><?= htmlspecialchars($doc['original_name']) ?></td>
                                    <td><span class="badge bg-secondary"><?= strtoupper($doc['file_type']) ?></span></td>
                                    <td>
                                        <?php
                                        $badge = match($doc['status']) {
                                            'completed' => 'success',
                                            'error'     => 'danger',
                                            'processing'=> 'warning',
                                            default     => 'secondary'
                                        };
                                        ?>
                                        <span class="badge bg-<?= $badge ?>"><?= $doc['status'] ?></span>
                                    </td>
                                    <td><?= htmlspecialchars($doc['category'] ?? '-') ?></td>
                                    <td><?= $doc['created_at'] ?></td>
                                    <td>
                                        <a href="view_document.php?id=<?= $doc['id'] ?>" class="btn btn-sm btn-outline-primary" title="Ver">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="download.php?id=<?= $doc['id'] ?>" class="btn btn-sm btn-outline-success" title="Descargar">
                                            <i class="bi bi-download"></i>
                                        </a>
                                        <a href="?repo=<?= $repoId ?>&delete=<?= $doc['id'] ?>" 
                                           class="btn btn-sm btn-outline-danger" 
                                           title="Eliminar"
                                           onclick="return confirm('¿Estás seguro de eliminar este documento?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>