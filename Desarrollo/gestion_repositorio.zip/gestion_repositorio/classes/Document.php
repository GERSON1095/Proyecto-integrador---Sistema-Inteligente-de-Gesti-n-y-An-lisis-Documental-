<?php
require_once __DIR__ . '/Database.php';

class Document {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO documents 
            (repository_id, user_id, original_name, stored_name, file_path, file_type, file_size, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        $stmt->execute([
            $data['repository_id'],
            $data['user_id'],
            $data['original_name'],
            $data['stored_name'],
            $data['file_path'],
            $data['file_type'],
            $data['file_size']
        ]);
        return $this->db->lastInsertId();
    }

    public function updateProcessingResult($id, $category, $summary, $extractedData, $fullText) {
        $stmt = $this->db->prepare("
            UPDATE documents SET 
                status = 'completed',
                category = ?,
                summary = ?,
                extracted_data = ?,
                full_text = ?,
                processed_at = NOW()
            WHERE id = ?
        ");
        return $stmt->execute([
            $category,
            $summary,
            json_encode($extractedData, JSON_UNESCAPED_UNICODE),
            $fullText,
            $id
        ]);
    }

    public function markAsError($id, $message) {
        $stmt = $this->db->prepare("UPDATE documents SET status = 'error', error_message = ? WHERE id = ?");
        return $stmt->execute([$message, $id]);
    }

    public function getByRepository($repositoryId) {
        $stmt = $this->db->prepare("SELECT * FROM documents WHERE repository_id = ? ORDER BY created_at DESC");
        $stmt->execute([$repositoryId]);
        return $stmt->fetchAll();
    }

    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM documents WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function search($userId, $query) {
        $stmt = $this->db->prepare("
            SELECT d.*, r.name as repo_name 
            FROM documents d
            JOIN repositories r ON d.repository_id = r.id
            WHERE d.user_id = ? AND d.status = 'completed'
            AND (d.original_name LIKE ? OR d.summary LIKE ? OR d.full_text LIKE ? OR d.category LIKE ?)
            ORDER BY d.created_at DESC
        ");
        $term = "%$query%";
        $stmt->execute([$userId, $term, $term, $term, $term]);
        return $stmt->fetchAll();
    }

    public function getStats($userId) {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors,
                SUM(CASE WHEN status = 'pending' OR status = 'processing' THEN 1 ELSE 0 END) as pending
            FROM documents WHERE user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch();
    }

    public function getStatsByRepository($repositoryId) {
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors,
                SUM(CASE WHEN status = 'pending' OR status = 'processing' THEN 1 ELSE 0 END) as pending
            FROM documents WHERE repository_id = ?
        ");
        $stmt->execute([$repositoryId]);
        return $stmt->fetch();
    }

    
    public function getCategoryStatsByRepository($repositoryId) {
        $stmt = $this->db->prepare("
            SELECT 
                COALESCE(category, 'Sin categoría') as category,
                COUNT(*) as total
            FROM documents 
            WHERE repository_id = ? AND status = 'completed'
            GROUP BY category
            ORDER BY total DESC
        ");
        $stmt->execute([$repositoryId]);
        return $stmt->fetchAll();
    }
}