<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Document.php';
require_once __DIR__ . '/../classes/Repository.php';

Auth::requireLogin();

$docModel = new Document();
$repoModel = new Repository();

$stats = $docModel->getStats(Auth::userId());
$repos = $repoModel->getByUser(Auth::userId());

$repoStats = [];
foreach ($repos as $repo) {
    $repoStats[$repo['id']] = $docModel->getStatsByRepository($repo['id']);
}
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="dashboard.php" class="list-group-item list-group-item-action active">
                    <i class="bi bi-speedometer2"></i> Dashboard General
                </a>
                <a href="repositories.php" class="list-group-item list-group-item-action">
                    <i class="bi bi-folder"></i> Repositorios
                </a>
                <a href="upload.php" class="list-group-item list-group-item-action">
                    <i class="bi bi-cloud-upload"></i> Subir Documento
                </a>
                <a href="search.php" class="list-group-item list-group-item-action">
                    <i class="bi bi-search"></i> Búsqueda / Chat IA
                </a>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="mb-4">Dashboard General</h2>
        
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card shadow-sm border-start border-primary border-4">
                        <div class="card-body py-3">
                            <h6 class="text-muted mb-1">Total Documentos</h6>
                            <h3 class="mb-0"><?= $stats['total'] ?? 0 ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm border-start border-success border-4">
                        <div class="card-body py-3">
                            <h6 class="text-muted mb-1">Procesados</h6>
                            <h3 class="mb-0 text-success"><?= $stats['completed'] ?? 0 ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm border-start border-warning border-4">
                        <div class="card-body py-3">
                            <h6 class="text-muted mb-1">Pendientes</h6>
                            <h3 class="mb-0 text-warning"><?= $stats['pending'] ?? 0 ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-sm border-start border-danger border-4">
                        <div class="card-body py-3">
                            <h6 class="text-muted mb-1">Errores</h6>
                            <h3 class="mb-0 text-danger"><?= $stats['errors'] ?? 0 ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-folder2-open"></i> Mis Repositorios</span>
                    <a href="repositories.php" class="btn btn-sm btn-outline-primary">Administrar</a>
                </div>
                <div class="card-body">
                    <?php if (empty($repos)): ?>
                        <p class="text-muted mb-0">Aún no tienes repositorios. <a href="repositories.php">Crea uno</a>.</p>
                    <?php else: ?>
                        <div class="row g-3">
                            <?php foreach ($repos as $repo): 
                                $rs = $repoStats[$repo['id']] ?? ['total' => 0, 'completed' => 0, 'pending' => 0, 'errors' => 0];
                            ?>
                                <div class="col-md-6">
                                    <div class="card h-100 border">
                                        <div class="card-body">
                                            <h5 class="card-title mb-1"><?= htmlspecialchars($repo['name']) ?></h5>
                                            <?php if (!empty($repo['description'])): ?>
                                                <p class="card-text text-muted small mb-3"><?= htmlspecialchars($repo['description']) ?></p>
                                            <?php else: ?>
                                                <p class="card-text text-muted small mb-3">Sin descripción</p>
                                            <?php endif; ?>

                                            <div class="d-flex gap-3 mb-3 small">
                                                <span title="Total"><i class="bi bi-files"></i> <?= $rs['total'] ?? 0 ?></span>
                                                <span class="text-success" title="Procesados"><i class="bi bi-check-circle"></i> <?= $rs['completed'] ?? 0 ?></span>
                                                <span class="text-warning" title="Pendientes"><i class="bi bi-hourglass"></i> <?= $rs['pending'] ?? 0 ?></span>
                                                <span class="text-danger" title="Errores"><i class="bi bi-x-circle"></i> <?= $rs['errors'] ?? 0 ?></span>
                                            </div>

                                            <a href="documents.php?repo=<?= $repo['id'] ?>" class="btn btn-sm btn-primary">
                                                <i class="bi bi-speedometer2"></i> Ver dashboard del repositorio
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>