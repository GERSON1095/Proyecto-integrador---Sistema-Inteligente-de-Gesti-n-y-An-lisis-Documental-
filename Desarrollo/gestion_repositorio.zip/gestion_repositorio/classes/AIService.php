<?php

class AIService {
    private string $apiKey;
    private string $baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

    public function __construct() {
       
        $this->apiKey = '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';
    }

    private function callGroq(array $messages, string $model = 'openai/gpt-oss-20b'): array {
        $data = [
            'model' => $model,
            'messages' => $messages,
            'temperature' => 0.2,
            'response_format' => ['type' => 'json_object']
        ];

        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey
            ],
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_TIMEOUT => 60
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("Error de conexión cURL: " . $error);
        }

        $result = json_decode($response, true);

        if ($httpCode !== 200) {
            $msg = $result['error']['message'] ?? $response;
            throw new Exception("Error de Groq (HTTP $httpCode): " . $msg);
        }

        if (!isset($result['choices'][0]['message']['content'])) {
            throw new Exception("Respuesta inesperada de Groq");
        }

        return $result;
    }

    public function processDocument(string $text): array {
        $text = mb_substr($text, 0, 12000);

        $prompt = <<<PROMPT
Eres un asistente experto en análisis documental empresarial.
Analiza el siguiente documento y responde ÚNICAMENTE con un JSON válido (sin markdown ni texto extra) con esta estructura exacta:

{
  "category": "una de estas categorías: Factura, Contrato, Informe, Correspondencia, Otro",
  "summary": "resumen claro y conciso en máximo 120 palabras",
  "extracted": {
    "fechas": ["lista de fechas encontradas"],
    "montos": ["lista de montos o valores monetarios"],
    "nombres": ["personas o empresas mencionadas"],
    "temas_principales": ["3 a 5 temas clave"]
  }
}

Documento:
$text
PROMPT;

        $messages = [
            ['role' => 'system', 'content' => 'Respondes siempre y únicamente en JSON válido.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $response = $this->callGroq($messages);
        $content = $response['choices'][0]['message']['content'];
        $result = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("La IA no devolvió un JSON válido");
        }

        return $result;
    }

    public function askQuestion(string $question, string $context): string {
        $prompt = "Contexto de los documentos:\n\n$context\n\n---\nPregunta del usuario: $question\n\nResponde de forma clara, profesional y cita la información del contexto cuando sea posible.";

        $messages = [
            ['role' => 'system', 'content' => 'Eres un asistente que responde preguntas basándose únicamente en el contexto proporcionado.'],
            ['role' => 'user', 'content' => $prompt]
        ];

        $data = [
            'model' => 'openai/gpt-oss-20b',
            'messages' => $messages,
            'temperature' => 0.3
        ];

        $ch = curl_init($this->baseUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $this->apiKey
            ],
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_TIMEOUT => 60
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $result = json_decode($response, true);

        if ($httpCode !== 200) {
            $msg = $result['error']['message'] ?? $response;
            throw new Exception("Error de Groq: " . $msg);
        }

        return $result['choices'][0]['message']['content'] ?? 'No se pudo obtener respuesta';
    }
}