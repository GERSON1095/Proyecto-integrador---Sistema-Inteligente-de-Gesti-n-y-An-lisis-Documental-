<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Document.php';
require_once __DIR__ . '/../classes/AIService.php';

Auth::requireLogin();

$docModel = new Document();
$results = [];
$answer = '';
$question = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['search_query']) && !empty($_POST['search_query'])) {
        $results = $docModel->search(Auth::userId(), $_POST['search_query']);
    }

    if (isset($_POST['question']) && !empty($_POST['question'])) {
        $question = trim($_POST['question']);
        
        $allDocs = $docModel->search(Auth::userId(), '');
        $context = '';
        foreach (array_slice($allDocs, 0, 5) as $d) {
            $context .= "Documento: {$d['original_name']}\nResumen: {$d['summary']}\n\n";
        }

        try {
            $ai = new AIService();
            $answer = $ai->askQuestion($question, $context);
        } catch (Exception $e) {
            $answer = 'Error al consultar la IA: ' . $e->getMessage();
        }
    }
}
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <h2 class="mb-4">Búsqueda y Consulta Inteligente</h2>

    <div class="row g-4">
        <!-- Búsqueda por texto -->
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header">Búsqueda dentro de documentos</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="input-group">
                            <input type="text" name="search_query" class="form-control" placeholder="Escribe palabras clave...">
                            <button class="btn btn-primary" type="submit">Buscar</button>
                        </div>
                    </form>

                    <?php if (!empty($results)): ?>
                        <hr>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($results as $r): ?>
                                <li class="list-group-item">
                                    <a href="view_document.php?id=<?= $r['id'] ?>">
                                        <?= htmlspecialchars($r['original_name']) ?>
                                    </a>
                                    <br>
                                    <small class="text-muted"><?= htmlspecialchars(mb_substr($r['summary'] ?? '', 0, 120)) ?>...</small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header">Pregunta sobre tus documentos (IA)</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <textarea name="question" class="form-control" rows="3" placeholder="Ej: ¿Cuáles son los montos de las facturas?" required><?= htmlspecialchars($question) ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-success">Preguntar a la IA</button>
                    </form>

                    <?php if ($answer): ?>
                        <hr>
                        <div class="alert alert-light border">
                            <strong>Respuesta:</strong><br>
                            <?= nl2br(htmlspecialchars($answer)) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>