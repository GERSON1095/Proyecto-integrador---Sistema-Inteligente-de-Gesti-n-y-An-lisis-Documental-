<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;

class DocumentExtractor {

    private string $ocrApiKey = 'K88725896188957';

    public function extract(string $filePath, string $fileType): string {
        $fileType = strtolower($fileType);

        try {
            switch ($fileType) {
                case 'pdf':
                    return $this->extractPdf($filePath);
                case 'docx':
                    return $this->extractDocx($filePath);
                case 'txt':
                    return $this->extractTxt($filePath);
                default:
                    throw new Exception("Formato no soportado: $fileType");
            }
        } catch (Exception $e) {
            throw new Exception("Error al extraer texto: " . $e->getMessage());
        }
    }

    private function extractPdf(string $path): string {
        // 1. Intentamos primero con el parser normal
        try {
            $parser = new Parser();
            $pdf = $parser->parseFile($path);
            $text = trim($pdf->getText());
            $text = preg_replace('/\s+/', ' ', $text);

            if (strlen($text) >= 30) {
                return $text; 
            }
        } catch (Exception $e) {
            
        }

        return $this->extractWithOCR($path);
    }

    private function extractWithOCR(string $filePath): string {
        $url = 'https://api.ocr.space/parse/image';

        $cfile = new CURLFile($filePath, 'application/pdf', basename($filePath));

        $postFields = [
            'apikey' => $this->ocrApiKey,
            'language' => 'spa',          
            'isOverlayRequired' => 'false',
            'file' => $cfile,
            'OCREngine' => '2'
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postFields,
            CURLOPT_TIMEOUT => 90
        ]);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("Error de conexión OCR: " . $error);
        }

        $result = json_decode($response, true);

        if (!isset($result['ParsedResults'][0]['ParsedText'])) {
            $msg = $result['ErrorMessage'][0] ?? 'No se pudo obtener texto con OCR';
            throw new Exception("OCR falló: " . $msg);
        }

        $text = trim($result['ParsedResults'][0]['ParsedText']);

        if (strlen($text) < 15) {
            throw new Exception("OCR no pudo extraer texto útil del PDF.");
        }

        return $text;
    }

    private function extractDocx(string $path): string {
        $phpWord = IOFactory::load($path);
        $text = '';

        foreach ($phpWord->getSections() as $section) {
            foreach ($section->getElements() as $element) {
                if (method_exists($element, 'getText')) {
                    $text .= $element->getText() . "\n";
                }
            }
        }

        $text = trim($text);
        if (empty($text)) {
            throw new Exception("No se pudo extraer texto del DOCX.");
        }
        return $text;
    }

    private function extractTxt(string $path): string {
        $content = file_get_contents($path);
        if ($content === false || trim($content) === '') {
            throw new Exception("No se pudo leer el archivo TXT.");
        }
        return $content;
    }
}