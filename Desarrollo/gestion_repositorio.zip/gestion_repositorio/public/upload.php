<?php
require_once __DIR__ . '/../classes/Auth.php';
require_once __DIR__ . '/../classes/Repository.php';
require_once __DIR__ . '/../classes/Document.php';
require_once __DIR__ . '/../classes/DocumentExtractor.php';
require_once __DIR__ . '/../classes/AIService.php';

Auth::requireLogin();

$repoModel = new Repository();
$repos = $repoModel->getByUser(Auth::userId());

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
    $file = $_FILES['document'];
    $repoId = (int)$_POST['repository_id'];

    $allowed = ['pdf' => 'application/pdf', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'txt' => 'text/plain'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!array_key_exists($ext, $allowed)) {
        $error = 'Solo se permiten archivos PDF, DOCX o TXT.';
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Error al subir el archivo.';
    } elseif ($file['size'] > 10 * 1024 * 1024) { // 10 MB
        $error = 'El archivo no puede superar los 10 MB.';
    } else {
        // Guardar archivo
        $storedName = uniqid() . '_' . time() . '.' . $ext;
        $destPath = __DIR__ . '/../storage/documents/' . $storedName;

        if (!is_dir(__DIR__ . '/../storage/documents')) {
            mkdir(__DIR__ . '/../storage/documents', 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $destPath)) {
            $docModel = new Document();
            $docId = $docModel->create([
                'repository_id' => $repoId,
                'user_id'       => Auth::userId(),
                'original_name' => $file['name'],
                'stored_name'   => $storedName,
                'file_path'     => $destPath,
                'file_type'     => $ext,
                'file_size'     => $file['size']
            ]);

            
            try {
                $extractor = new DocumentExtractor();
                $text = $extractor->extract($destPath, $ext);

                $ai = new AIService();
                $result = $ai->processDocument($text);

                $docModel->updateProcessingResult(
                    $docId,
                    $result['category'] ?? 'Otro',
                    $result['summary'] ?? '',
                    $result['extracted'] ?? [],
                    $text
                );

                $message = 'Documento subido y procesado correctamente con IA.';
            } catch (Exception $e) {
                $docModel->markAsError($docId, $e->getMessage());
                $error = 'Documento subido, pero falló el procesamiento IA: ' . $e->getMessage();
            }
        } else {
            $error = 'No se pudo guardar el archivo en el servidor.';
        }
    }
}
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <h2 class="mb-4">Subir Documento</h2>

    <?php if ($message): ?>
        <div class="alert alert-success"><?= $message ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Repositorio</label>
                    <select name="repository_id" class="form-select" required>
                        <option value="">Seleccione un repositorio</option>
                        <?php foreach ($repos as $repo): ?>
                            <option value="<?= $repo['id'] ?>"><?= htmlspecialchars($repo['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Archivo (PDF, DOCX o TXT – máx. 10 MB)</label>
                    <input type="file" name="document" class="form-control" accept=".pdf,.docx,.txt" required>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-cloud-upload"></i> Subir y Procesar con IA
                </button>
                <a href="dashboard.php" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>