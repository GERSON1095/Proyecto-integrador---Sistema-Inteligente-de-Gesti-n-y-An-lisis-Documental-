<?php
require_once __DIR__ . '/Database.php';

class Repository {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function create($userId, $name, $description = null) {
        $stmt = $this->db->prepare("INSERT INTO repositories (user_id, name, description) VALUES (?, ?, ?)");
        $stmt->execute([$userId, $name, $description]);
        return $this->db->lastInsertId();
    }

    public function getByUser($userId) {
        $stmt = $this->db->prepare("SELECT * FROM repositories WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$userId]);
        return $stmt->fetchAll();
    }

    public function findById($id, $userId) {
        $stmt = $this->db->prepare("SELECT * FROM repositories WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $userId]);
        return $stmt->fetch();
    }

    public function delete($id, $userId) {
        $stmt = $this->db->prepare("DELETE FROM repositories WHERE id = ? AND user_id = ?");
        return $stmt->execute([$id, $userId]);
    }
}